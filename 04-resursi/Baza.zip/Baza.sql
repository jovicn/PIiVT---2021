-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.6.0-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for praktikum
DROP DATABASE IF EXISTS `praktikum`;
CREATE DATABASE IF NOT EXISTS `praktikum` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `praktikum`;

-- Dumping structure for table praktikum.administrator
DROP TABLE IF EXISTS `administrator`;
CREATE TABLE IF NOT EXISTS `administrator` (
  `administrator_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`administrator_id`),
  UNIQUE KEY `uq_administrator_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table praktikum.administrator: ~4 rows (approximately)
/*!40000 ALTER TABLE `administrator` DISABLE KEYS */;
REPLACE INTO `administrator` (`administrator_id`, `username`, `password_hash`, `is_active`) VALUES
	(1, 'jnikola', '$2b$10$B39Yv/qOtNN1TUSwk7JC2ezLY/9FSqYQj71nf5e5RbGuNwoIvs2H2', 1),
	(3, 'jovicnikola', '$2b$10$f5UrvLVPoOe6HGpvka0CrOT0GAnMN2nZttlLNXfl1zRKrc7y9k0gu', 0),
	(4, 'mikamikic', '$2b$10$W0Iw4FXvQkX4eCU5Z8yCcu3FmRsPEjOdk7PFS/ke.suowGnQPlsZK', 0),
	(5, 'urosurosevic', '$2b$10$On753j1yRcMEURxsxdZ5aO2d6TnZSyJrri4SaENWSzG8nhN/kpeMq', 1),
	(6, 'milosm', '$2b$10$p0Eu59KB7qzGI//J2v4vzO6DfuurNeSGDuMZ1yPvlWZagdsQeUpmW', 1);
/*!40000 ALTER TABLE `administrator` ENABLE KEYS */;

-- Dumping structure for table praktikum.bazen
DROP TABLE IF EXISTS `bazen`;
CREATE TABLE IF NOT EXISTS `bazen` (
  `bazen_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ime` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresa` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grad` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `broj_mesta` int(10) unsigned NOT NULL DEFAULT 0,
  `telefon` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bazen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table praktikum.bazen: ~8 rows (approximately)
/*!40000 ALTER TABLE `bazen` DISABLE KEYS */;
REPLACE INTO `bazen` (`bazen_id`, `ime`, `adresa`, `grad`, `broj_mesta`, `telefon`) VALUES
	(1, 'Bazen Olimp', 'Bulevar Zorana Djindjica 32', 'Beograd', 200, '0112547845'),
	(2, 'Bazen Flamingo ', 'Trg Oslobodnjena 13', 'Nis', 200, '0185478547'),
	(3, 'Bazen & Spa Olimpic', 'Neznanog junaka 172', 'Novi Sad', 250, '0214578124'),
	(4, 'Bazen Singidunum', 'Vojvode Misica 57', 'Beograd', 300, '0112587489'),
	(5, 'Bazen Nais ', 'Bulevar Nemanjica 62', 'Nis', 230, '0184587965'),
	(6, 'Bazen Arena', 'Sarajevska 43', 'Novi Sad', 200, '0214789654'),
	(9, 'Bazen Delfin', 'Adresa 43', 'Beograd', 220, '011458789'),
	(10, 'Bazen Ajkula', 'Adresa 91', 'Nis', 300, '018457871');
/*!40000 ALTER TABLE `bazen` ENABLE KEYS */;

-- Dumping structure for table praktikum.korisnik
DROP TABLE IF EXISTS `korisnik`;
CREATE TABLE IF NOT EXISTS `korisnik` (
  `korisnik_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ime` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prezime` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefon` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`korisnik_id`),
  UNIQUE KEY `uq_korisnik_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table praktikum.korisnik: ~5 rows (approximately)
/*!40000 ALTER TABLE `korisnik` DISABLE KEYS */;
REPLACE INTO `korisnik` (`korisnik_id`, `ime`, `prezime`, `email`, `telefon`, `password_hash`, `created_at`, `is_active`) VALUES
	(3, 'Nikola', 'Jovic', 'nikola@mail.com', '0645789456', '$2b$10$3nB82FE.8NyH6boMFKmlx.oZ9tL.h4t6m9KjRupwu/n2i8V6Nv4Ze', '2021-06-11 19:38:40', 1),
	(4, 'Milos', 'Markovic', 'milos@mail.com', '0611879654', '$2b$10$9VWeZhp7mafhZeK7nVYar.sMSy.XXHMWl7Kf0A8/lcTL29C9RfBsK', '2021-06-11 19:40:40', 1),
	(7, 'Marko', 'Stefanovic', 'marko@mail.com', '0618845712', '$2b$10$l89CzuYy/qXkVZ1sJmBlWuaLs2jGiC.7brcSV3uyGCmaQZtXbfCGq', '2021-06-11 19:43:51', 1),
	(8, 'Milos', 'Jovic', 'milosj@mail.com', '0645789456', '$2b$10$HPcgfO/3wReLVHDB8syYU.ML3lGyfFqjyg.2hm6/V6mueNHE6wHRi', '2021-06-15 14:30:38', 1),
	(9, 'Nikola', 'Jovic', 'jovic@mail.com', '0645789456', '$2b$10$M/YlFpjf2lh4HtcxSZBhLOw/46q3yY37fNCtVOUQPuvfcE3/GybeG', '2021-06-15 14:38:27', 1);
/*!40000 ALTER TABLE `korisnik` ENABLE KEYS */;

-- Dumping structure for table praktikum.korisnik_termin
DROP TABLE IF EXISTS `korisnik_termin`;
CREATE TABLE IF NOT EXISTS `korisnik_termin` (
  `korisnik_termin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `korisnik_id` int(10) unsigned NOT NULL,
  `termin_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`korisnik_termin_id`),
  UNIQUE KEY `uq_korisnik_termin_korisnik_id_termin_id` (`korisnik_id`,`termin_id`),
  KEY `fk_korisnik_termin_termin_id` (`termin_id`),
  KEY `fk_korisnik_termin_korisnik_id` (`korisnik_id`),
  CONSTRAINT `fk_korisnik_termin_korisnik_id` FOREIGN KEY (`korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_korisnik_termin_termin_id` FOREIGN KEY (`termin_id`) REFERENCES `termin` (`termin_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table praktikum.korisnik_termin: ~4 rows (approximately)
/*!40000 ALTER TABLE `korisnik_termin` DISABLE KEYS */;
REPLACE INTO `korisnik_termin` (`korisnik_termin_id`, `korisnik_id`, `termin_id`, `created_at`) VALUES
	(5, 7, 1, '2021-06-14 00:41:35'),
	(6, 4, 1, '2021-06-14 00:41:44'),
	(7, 3, 3, '2021-06-14 16:56:47'),
	(8, 3, 1, '2021-06-14 16:57:49'),
	(17, 3, 15, '2021-06-18 13:59:31');
/*!40000 ALTER TABLE `korisnik_termin` ENABLE KEYS */;

-- Dumping structure for table praktikum.stranica
DROP TABLE IF EXISTS `stranica`;
CREATE TABLE IF NOT EXISTS `stranica` (
  `stranica_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `naziv` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tekst` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`stranica_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table praktikum.stranica: ~3 rows (approximately)
/*!40000 ALTER TABLE `stranica` DISABLE KEYS */;
REPLACE INTO `stranica` (`stranica_id`, `naziv`, `tekst`) VALUES
	(1, 'Pravila o korišćenju bazena', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32. '),
	(2, 'Pravila o registarciji termina', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32. '),
	(3, 'Uputstvo za registarciju', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\\\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.');
/*!40000 ALTER TABLE `stranica` ENABLE KEYS */;

-- Dumping structure for table praktikum.termin
DROP TABLE IF EXISTS `termin`;
CREATE TABLE IF NOT EXISTS `termin` (
  `termin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zakazan_at` datetime NOT NULL,
  `status` enum('aktivan','otkazan') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'aktivan',
  `bazen_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`termin_id`),
  UNIQUE KEY `uq_termin_vreme_bazen_id` (`zakazan_at`,`bazen_id`) USING BTREE,
  KEY `fk_termin_bazen_id` (`bazen_id`),
  CONSTRAINT `fk_termin_bazen_id` FOREIGN KEY (`bazen_id`) REFERENCES `bazen` (`bazen_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table praktikum.termin: ~8 rows (approximately)
/*!40000 ALTER TABLE `termin` DISABLE KEYS */;
REPLACE INTO `termin` (`termin_id`, `zakazan_at`, `status`, `bazen_id`) VALUES
	(1, '2021-07-10 16:00:00', 'aktivan', 1),
	(2, '2021-07-13 18:00:00', 'aktivan', 3),
	(3, '2021-07-10 15:00:00', 'aktivan', 4),
	(11, '2021-07-07 13:00:00', 'otkazan', 6),
	(12, '2021-07-25 16:00:00', 'aktivan', 9),
	(13, '2021-07-18 15:00:00', 'aktivan', 1),
	(14, '2021-08-09 10:00:00', 'aktivan', 1),
	(15, '2021-06-07 19:00:00', 'aktivan', 6);
/*!40000 ALTER TABLE `termin` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
